test = {
  'name': 'Question 8',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'answer': '3aecc002acdd55b90bdf48d167af4901',
          'choices': [
            'It contains a nested function',
            'It calls a function that is not itself',
            'It takes in a function as an argument',
            'It uses the *args keyword'
          ],
          'hidden': False,
          'locked': True,
          'multiline': False,
          'question': 'What is one reason that make_averaged is a higher order function?'
        },
        {
          'answer': '3d95d25ee7e350e316499577c8bd0d99',
          'choices': [
            'None',
            'Two',
            'An arbitrary amount, which is why we need to use *args to call it'
          ],
          'hidden': False,
          'locked': True,
          'multiline': False,
          'question': 'How many arguments does the function passed into make_averaged take?'
        }
      ],
      'scored': False,
      'type': 'concept'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> dice = make_test_dice(3, 1, 5, 6)
          >>> averaged_dice = make_averaged(dice, 1000)
          >>> # Average of calling dice 1000 times
          >>> averaged_dice()
          af48b6e78417ff83f674305e5faaf184
          # locked
          """,
          'hidden': False,
          'locked': True,
          'multiline': False
        },
        {
          'code': r"""
          >>> dice = make_test_dice(3, 1, 5, 6)
          >>> averaged_roll_dice = make_averaged(roll_dice, 1000)
          >>> # Average of calling roll_dice 1000 times
          >>> # Enter a float (e.g. 1.0) instead of an integer
          >>> averaged_roll_dice(2, dice)
          db8547ec657de21a7de51efb79db0bc8
          # locked
          """,
          'hidden': False,
          'locked': True,
          'multiline': False
        }
      ],
      'scored': True,
      'setup': r"""
      >>> from hog import *
      """,
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> hundred_range = range(1, 100)
          >>> hundred_dice = make_test_dice(*hundred_range)
          >>> averaged_hundred_dice = make_averaged(hundred_dice, 5*len(hundred_range))
          >>> correct_average = sum(range(1, 100)) / len(hundred_range)
          >>> averaged_hundred_dice()
          50.0
          >>> averaged_hundred_dice()
          50.0
          """,
          'hidden': False,
          'locked': True,
          'multiline': False
        },
        {
          'code': r"""
          >>> dice = make_test_dice(3, 1, 5, 6)
          >>> averaged_roll_dice = make_averaged(roll_dice, 1)
          >>> averaged_roll_dice(2, dice)
          1.0
          """,
          'hidden': False,
          'locked': True,
          'multiline': False
        },
        {
          'code': r"""
          >>> dice = make_test_dice(3, 1, 5, 6)
          >>> averaged_roll_dice = make_averaged(roll_dice, 5)
          >>> averaged_roll_dice(2, dice)
          5.0
          """,
          'hidden': False,
          'locked': True,
          'multiline': False
        }
      ],
      'scored': True,
      'setup': r"""
      >>> from hog import *
      """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
